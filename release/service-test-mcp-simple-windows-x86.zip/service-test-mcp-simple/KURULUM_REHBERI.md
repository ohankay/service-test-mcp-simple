# service-test-mcp-simple: Kurulum Rehberi (GitHub Copilot ajanı için)

## Kullanıcı için (1 dakika)

1. Python'unuza uygun zip'i indirin ve bir klasöre açın, örneğin `C:\Araclar\service-test-mcp-simple`:
   - **64-bit Python** (çoğu bilgisayar): `service-test-mcp-simple-windows-x64.zip`
   - **32-bit Python**: `service-test-mcp-simple-windows-x86.zip`

   Hangisi olduğunu bilmiyorsanız: `py -c "import struct; print(struct.calcsize('P')*8)"` komutu `64` veya `32` yazar. Yanlış zip'i seçerseniz kurulum bunu söyler.
2. VS Code'da **File → Open Folder** ile bu klasörü açın.
3. Copilot Chat'i açın, modu **Agent** yapın ve şunu yazın:

   > `KURULUM_REHBERI.md dosyasını oku ve "Ajan için kurulum adımları" bölümünü sırayla uygula.`

4. Ajan size servislerinizi ve kimlik doğrulama tipini soracak, kurulumu kendisi yapacak.
   **Şifre veya token'ı sohbete asla yazmayın.** VS Code bunları ilk başlatmada güvenli bir kutuda soracak.

Gereksinimler: Windows 10/11 (64 veya 32 bit), Python 3.10–3.14. İnternet gerekmez, tüm paketler `wheelhouse` klasöründe.

Not: Kurulum sırasında terminalde bir kez `install.cmd` çalışır. Kurulumdan sonra servis çağrıları için PowerShell hiç kullanılmaz.

---

## Ajan için kurulum adımları

> Sen bu kurulumu yapan GitHub Copilot ajanısın. Adımları **sırayla** uygula. Her adımın sonucunu kullanıcıya kısa bir cümleyle bildir. Bir adım başarısız olursa sonraki adıma geçme; "Sorun giderme" bölümüne bak, çözemiyorsan kullanıcıya hatayı olduğu gibi göster.
>
> **Kesin kurallar:**
> - Kullanıcıdan şifre veya token İSTEME; bunları hiçbir dosyaya, komuta, ortam değişkenine veya `.env` dosyasına YAZMA. Gizli değerler yalnızca `mcp.json` içindeki `${input:...}` girdileriyle VS Code tarafından sorulur.
> - `services.yaml` içine şifre/token YAZMA; sadece `password_env` / `token_env` / `value_env` ile değişken ADI yazılır.
> - Prod ortam TANIMLAMA (prod, production, prd, canli, live adları zaten reddedilir).
> - Kullanıcının mevcut `mcp.json` dosyasındaki diğer sunuculara ve girdilere DOKUNMA; sadece `service-test` sunucusunu ve onun `inputs` girdilerini ekle/güncelle.
> - Paketleri elle `pip install` ile KURMA; kurulum yalnızca `install.cmd` ile yapılır.
> - Komutları VS Code'un varsayılan terminalinde (PowerShell) çalıştır.

### Adım 1: Paketleri kur

Bu rehberin bulunduğu klasörde (zip'in açıldığı kök klasör) çalıştır:

```powershell
cmd /c install.cmd; "EXIT=$LASTEXITCODE"
```

- Çıktıda `KURULUM TAMAM` ve `EXIT=0` görmelisin.
- Kurulum yeri: `%USERPROFILE%\.service-test-mcp`. Komutlar: `Scripts\service-test-mcp.exe` (MCP sunucusu) ve `Scripts\service-test-agent.exe` (bağımsız ajan).
- Hata kodları: `10` = uygun Python yok, `11` = venv oluşturulamadı, `12` = paket kurulamadı, `13` = komut çalışmadı, `14` = zip ile Python'un mimarisi farklı (diğer zip gerekiyor), `15` = mevcut kurulum farklı mimaride, `16` = kurulum sonrası doğrulama başarısız.

### Adım 2: Kullanıcıya demo mu, gerçek servisler mi diye sor

- **Demo:** Adım 3'ü atla, Adım 4'te `templates/mcp.demo.json` şablonunu kullan; `DEMO_KLASORU` yerine bu klasördeki `demo` klasörünün tam yolunu yaz. Kullanıcıya demo servisini ayrı bir terminalde başlatmasını söyle: `& "$env:USERPROFILE\.service-test-mcp\Scripts\service-test-mcp.exe" --demo-server`
- **Gerçek servisler:** Adım 3'e geç.

### Adım 3: Servis kataloğunu oluştur

Kullanıcıya şu soruları tek mesajda sor (şifre SORMA):

1. Ortam adları (örn. `test`, `preprod`) ve varsayılan ortam.
2. Her servis için: adı, tipi (`soap` / `rest`), ortam bazında WSDL adresi (SOAP) veya base URL (REST), varsa OpenAPI/Swagger adresi.
3. Kimlik doğrulama: `windows` (Windows oturumu, şifresiz - WCF'de en yaygın), `ntlm` (servis kullanıcısı + şifre), `basic`, `bearer` (token), `api_key`, `ws_username_token` (WS-Security), `client_cert`, `none`.
4. Veri değiştiren (mutating) operasyonlar: SOAP'ta operasyon adları (`TransferYap`, `*Sil`), REST'te `METHOD /yol` kalıpları.
5. Kurumsal proxy veya kendi CA sertifikası gerekiyor mu?

Sonra `templates/services.yaml` dosyasını `%USERPROFILE%\.service-test-mcp\services.yaml` olarak kopyala ve kullanıcının cevaplarıyla doldur. Şifreli her servis için `password_env: STM_PW_<SERVIS>` / `token_env: STM_TOKEN_<SERVIS>` gibi bir değişken adı ver.

Bağlantıyı test et (şifresiz tipler için; şifreli tiplerde Adım 6'ya bırak):

```powershell
$env:STM_CONFIG = "$env:USERPROFILE\.service-test-mcp\services.yaml"
& "$env:USERPROFILE\.service-test-mcp\Scripts\service-test-mcp.exe" --check; "EXIT=$LASTEXITCODE"
Remove-Item Env:STM_CONFIG
```

`EXIT=0` ise her servis `ok: true` görünür. Değilse `error` mesajını kullanıcıya göster ve "Sorun giderme"ye bak.

### Adım 4: VS Code MCP yapılandırmasını yaz

Hedef dosya, **kullanıcı düzeyi**: `"$env:APPDATA\Code\User\mcp.json"` (Insiders: `$env:APPDATA\Code - Insiders\User\mcp.json`).

| Durum | Şablon |
|---|---|
| Demo | `templates/mcp.demo.json` |
| Tüm servisler `windows` / `none` | `templates/mcp.windows-auth.json` |
| Şifre / token gereken servis var | `templates/mcp.secrets.json` |

Kurallar:

- `services.yaml` içindeki **her** `*_env` adı için iki şey ekle: `inputs` dizisine bir `promptString` girdisi (`"password": true`) ve `service-test` sunucusunun `env` bölümüne `"STM_PW_X": "${input:stm-pw-x}"` satırı. Adlar **harfi harfine aynı** olmalı. Şablondaki örnek girdilerden kullanılmayanları sil.
- Senaryolarda login şifresi gerekiyorsa adı `STM_SECRET_` ile başlayan bir değişken ekle (senaryoda `{{secret.STM_SECRET_X}}`).
- **Dosya yoksa:** şablonun tamamıyla oluştur. **Dosya varsa:** `servers` altına yalnızca `"service-test"` anahtarını ekle/güncelle, `inputs` girdilerini aynı `id` yoksa ekle.
- `%USERPROFILE%\.service-test-mcp` dışında bir yere kurulduysa (`STM_INSTALL_HOME`), `command` alanına tam yolu yaz.

Dosyayı yazdıktan sonra geçerli JSON olduğunu kontrol et.

### Adım 5: Copilot custom agent ve yönergeler (isteğe bağlı)

Kullanıcıya "Servis testleri için hazır bir custom agent ister misin?" diye sor. Evet derse kullanıcının proje klasörüne:

- `templates/service-tester.agent.md` → `.github/agents/service-tester.agent.md`
- `templates/copilot-instructions.md` içeriği → `.github/copilot-instructions.md` (dosya varsa sonuna ekle)

### Adım 6: Kullanıcıya son adımları söyle

1. `Ctrl+Shift+P` → **MCP: List Servers** → **service-test** → **Start Server**. Güven onayı gelirse **Trust** deyin.
2. Şifre/token tanımlandıysa VS Code her birini bir kez soracak ve güvenli depoda saklayacak.
3. Copilot Chat → **Agent** modu → araç (🔧) simgesinde `service-test` altında 12 araç görünmeli.
4. Test için: **"service-test check_service çalıştır"**. Demo için: **"demo/scenarios klasöründeki senaryoları run_test_suite ile koş"**.
5. Sorun olursa: **MCP: List Servers** → **service-test** → **Show Output**.

Kurulum burada biter.

---

## Sorun giderme

| Belirti | Neden / Çözüm |
|---|---|
| `install.cmd` → EXIT 10 | Python 3.10–3.14 yok veya PATH'te değil. Python 3.12'yi kurun ("Add to PATH" ve "py launcher" seçili), VS Code'u yeniden açın. |
| EXIT 11 | `%USERPROFILE%` yazılamıyor ya da antivirüs engelliyor. `set STM_INSTALL_HOME=D:\Araclar\service-test-mcp` ile başka klasöre kurun. |
| EXIT 12 | `wheelhouse` eksik veya Python sürümü desteklenmiyor (3.15+). Zip'i yeniden açın ya da Python 3.12 kullanın. |
| EXIT 14 | Zip ile Python'un mimarisi farklı. Mesajda adı geçen diğer zip'i kullanın. |
| EXIT 15 / 16 / `No module named 'pywintypes'` | Yarım veya farklı mimaride eski kurulum. `%USERPROFILE%\.service-test-mcp\Scripts` ve `Lib` klasörlerini silip `install.cmd`'yi tekrar çalıştırın (`services.yaml` ve `logs` korunabilir). |
| `environment variable 'STM_...' is not set` | `services.yaml`'daki `*_env` adı `mcp.json` `env` bölümünde yok veya farklı yazılmış. Adları aynı yapın, sunucuyu **Restart** edin. |
| `Host '...' is not in the allowlist` | WSDL, yapılandırmadakinden farklı bir adres yayınlıyor (WCF'de makine adı / load balancer). O ortam için `endpoint` yazın veya host'u `allowed_hosts`'a ekleyin. |
| `401 Unauthorized` (SOAP veya REST) | Kimlik doğrulama tipi yanlış. WCF `Windows` güvenliği için `windows` (şifresiz) veya `ntlm`; IIS basic için `basic`. |
| `SSL` / `CERTIFICATE_VERIFY_FAILED` | Kurum CA sertifikası tanınmıyor. Ortamda `verify_tls: C:\certs\kurum-ca.pem` yazın (yalnızca test ortamında gerekirse `false`). |
| `Max retries` / `Failed to resolve` | Adres yanlış, VPN/proxy gerekli. Ortamda `proxy:` tanımlayın. |
| `The WSDL has no SOAP port` | Servis yalnızca `netTcpBinding` / `netNamedPipeBinding` sunuyor. Servis ekibinden test ortamı için `basicHttpBinding` endpoint'i isteyin. |
| `is marked as mutating` | Operasyon `mutating_operations` listesinde. Gerçekten gerekiyorsa yalnızca test ortamında `allow_mutating: true` yapın. |
| Sunucu başlıyor ama araçlar görünmüyor | Chat modu **Agent** olmalı. Copilot Business/Enterprise'da "MCP servers in Copilot" politikası açık olmalı. |
| `spawn ... ENOENT` | `command` yolu yanlış; `%USERPROFILE%\.service-test-mcp\Scripts\service-test-mcp.exe` var mı kontrol edin. |

## Güncelleme ve kaldırma

- **Güncelleme:** Yeni zip'i açın ve `install.cmd`'yi tekrar çalıştırın; `mcp.json` ve `services.yaml` değişmez.
- **Kaldırma:** `%USERPROFILE%\.service-test-mcp` klasörünü silin ve `mcp.json` içinden `service-test` girdisini kaldırın.
